//
//  TJIAP.h
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/2/17.
//
//

#import <Foundation/Foundation.h>
#import "StoreKit/StoreKit.h"

@interface TJIAP : NSObject<SKProductsRequestDelegate, SKPaymentTransactionObserver>

@property(nonatomic, strong)NSString *receipt;
@property(nonatomic, strong)NSString *date;
@property(nonatomic, strong)NSString *userid;
@property(nonatomic, strong)NSMutableData *receiveData;

+ (TJIAP *) shareTJIAP;

- (void)buyProdution:(NSString *)param;
@end
