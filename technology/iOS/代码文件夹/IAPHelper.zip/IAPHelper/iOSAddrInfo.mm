//
//  iOSAddrInfo.m
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/3/9.
//
//

#import "iOSAddrInfo.h"
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <err.h>
#define OUTSTR_SIZE 4096

extern "C" {
    const char* copyStr( const char* str )
    {
        char* s = (char*)malloc(strlen(str) + 1);
        strcpy(s, str);
        return s;
    }
    
    const char* IOSGetAddressInfo(const char *host){
        if(NULL == host)
            return copyStr("ERROR_HOSTNULL");
        char outstr[OUTSTR_SIZE];
        struct addrinfo hints, *res, *res0;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = PF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_DEFAULT;
        printf("getaddrinfo: %s\n", host);
        int error = getaddrinfo(host, "http", &hints, &res0);
        if (error != 0)
        {
            printf("getaddrinfo: %s\n", gai_strerror(error));
            return copyStr("ERROR_GETADDR");
        }
        memset( outstr, 0, sizeof(char)*OUTSTR_SIZE);
        struct sockaddr_in6* addr6;
        struct sockaddr_in* addr;
        const char* solvedaddr;
        char ipbuf[32];
        for (res = res0; res; res = res->ai_next)
        {
            if (res->ai_family == AF_INET6)
            {
                addr6 =(struct sockaddr_in6*)res->ai_addr;
                solvedaddr = inet_ntop(AF_INET6, &addr6->sin6_addr, ipbuf, sizeof(ipbuf));
                strcat(outstr, "ipv6|");
                strcat(outstr, solvedaddr);
                
            }
            else
            {
                addr =( struct sockaddr_in*)res->ai_addr;
                solvedaddr = inet_ntop(AF_INET, &addr->sin_addr, ipbuf, sizeof(ipbuf));
                strcat ( outstr, "ipv4|");
                strcat ( outstr, solvedaddr);
            }
            strcat (outstr, "|");
        }
        return copyStr(outstr);
    }
}
