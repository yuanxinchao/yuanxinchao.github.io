//
//  TJIAP.m
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/2/17.
//
//

#import "TJIAP.h"
#import "MBProgressHUD+TJ.h"
#import "NSString+Base64.h"
#import "AFNetworking.h"

#define AppStoreInfoLocalFilePath [NSString stringWithFormat:@"%@/%@/", [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject],@"EACEF35FE363A75A"]

#define HOSTURL @"http://test.tomatojoy.cn:30041/ldpk"
//#define HOSTURL @"https://sandbox.itunes.apple.com/verifyReceipt"
//#define HOSTURL @"http://192.168.31.206:8080/index"

#define USERID @"userid"
#define DATE @"date"
#define RECEIPT @"receipt"

@implementation TJIAP

static TJIAP *instance = nil;

/**单例模式对外的唯一接口，用到的dispatch_once函数在一个应用程序内只会执行一次，且dispatch_once能确保线程安全*/
+ (TJIAP *) shareTJIAP {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    });
    return instance;
}

/**覆盖该方法主要确保当用户通过[[Singleton alloc] init]创建对象时对象的唯一性，alloc方法会调用该方法，只不过zone参数默认为nil，因该类覆盖了allocWithZone方法，所以只能通过其父类分配内存，即[super allocWithZone:zone]*/
+ (id)allocWithZone:(struct _NSZone *)zone{
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        if(instance == nil){
            instance = [super allocWithZone:zone];
        }
    });
    return instance;
}

//覆盖该方法主要确保当用户通过copy方法产生对象时对象的唯一性
- (id)copy{
    return self;
}

//覆盖该方法主要确保当用户通过mutableCopy方法产生对象时对象的唯一性
- (id)mutableCopy{
    return self;
}

//自定义初始化方法
- (instancetype)init{
    self = [super init];
    if(self){
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    }
    return self;
}

//移除监听
-(void)dealloc
{
    NSLog(@"dealloc");
    [super dealloc];
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
}


- (void)buyProdution:(NSString *)param{
    if([SKPaymentQueue canMakePayments]){
        NSLog(@"buyProdution : %@", param);
        NSArray *array = [param componentsSeparatedByString:@"&"];
        NSArray *arr = [array[2] componentsSeparatedByString:@"a"];
        self.userid = arr[0];
        self.date = [[NSDate date] description];
        NSLog(@"AAAAAA%@, %@, %@", self.userid, self.date, arr[1]);
        [self getProductInfo:[NSString stringWithFormat:@"com.tomatojoy.pkdld.%@", arr[1]]];
    }else{
        [MBProgressHUD showMessage:@"用户禁止应用内付费购买" afterHide:1.0];
    }
}

//从Apple查询用户点击购买的产品的信息
- (void)getProductInfo:(NSString *)productIdentifier{
    NSArray *product = [[NSArray alloc] initWithObjects:productIdentifier, nil];
    NSSet *set = [NSSet setWithArray:product];
    SKProductsRequest *request = [[SKProductsRequest alloc] initWithProductIdentifiers:set];
    request.delegate = self;
    [request start];
    [MBProgressHUD showMessage:@"正在购买，请稍后"];
}

// 查询成功后的回调
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    [MBProgressHUD hideHUD];
    NSArray *myProduct = response.products;
    if (myProduct.count == 0) {
        [MBProgressHUD showMessage:@"无法获取产品信息，请重试" afterHide:1.0];
        return;
    }
    SKPayment * payment = [SKPayment paymentWithProduct:myProduct[0]];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

//查询失败后的回调
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    [MBProgressHUD hideHUD];
    [MBProgressHUD showMessage:[error localizedDescription] afterHide:1.0];
}

//购买操作后的回调
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
    [MBProgressHUD hideHUD];
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased://交易完成
                self.receipt = [NSString base64StringFromData:[NSData dataWithContentsOfURL:[[NSBundle mainBundle] appStoreReceiptURL]] length:[NSData dataWithContentsOfURL:[[NSBundle mainBundle] appStoreReceiptURL]].length];
                [self checkReceiptIsValid];//把self.receipt发送到服务器验证是否有效
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed://交易失败
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored://已经购买过该商品
                [MBProgressHUD showMessage:@"恢复购买成功" afterHide:1.0];
                [self restoreTransaction:transaction];
                break;
            case SKPaymentTransactionStatePurchasing://商品添加进列表
                [MBProgressHUD showMessage:@"正在请求付费信息，请稍后"];
                break;
            default:
                break;
        }
    }
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}


- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    if(transaction.error.code != SKErrorPaymentCancelled) {
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"购买失败，请重试"delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"重试", nil];
//        [alertView show];
        [MBProgressHUD showMessage:@"购买失败，请重试" afterHide:1.5];
    } else {
        [MBProgressHUD showMessage:@"用户取消交易" afterHide:1.2];
    }
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

- (void)restoreTransaction:(SKPaymentTransaction *)transaction {
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}

- (void)checkReceiptIsValid{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                                    self.userid, USERID,
//                                    self.date, DATE,
                                    self.receipt, RECEIPT,
                                    nil];
    NSLog(@"checkReceiptIsValid");
//    NSString *urlStr = [NSString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@", HOSTURL, USERID, self.userid, DATE, self.date, RECEIPT, self.receipt];
////    NSLog(@"%@", urlStr);
//    NSURL *url = [NSURL URLWithString:urlStr];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:30];
//    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
//    NSString *str = [[NSString alloc]initWithData:received encoding:NSUTF8StringEncoding];
//    NSLog(@"++++++++++%@",str);
    
    //第二步，创建请求
//    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30];
    //第三步，连接服务器
//    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    
    [[AFHTTPSessionManager manager]GET:HOSTURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"success");
        self.receipt = nil;
        self.userid = nil;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"failure");
    }];
    
    
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//        [manager GET:HOSTURL parameters:params progress:nil
//        success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//            NSLog(@"responseObject--> %@", responseObject);
//        }
//        failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//            [self saveReceipt];
//            NSLog(@"checkReceiptIsValid failure %@", [error description]);
//    }];
}
    
//接收到服务器回应的时候调用此方法
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
    NSLog(@"%@",[res allHeaderFields]);
    self.receiveData = [NSMutableData data];
}

//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [self.receiveData appendData:data];
}

//数据传完之后调用此方法
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSString *receiveStr = [[NSString alloc]initWithData:self.receiveData encoding:NSUTF8StringEncoding];
    NSLog(@"++++%@",receiveStr);
}

//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"%@",[error localizedDescription]);
}

    
//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    if (buttonIndex == 0){
////        [self saveReceipt];
//        NSLog(@"123");
//    }else{
////        [self checkReceiptIsValid];
//        NSLog(@"321");
//    }
//}

//AppUtils 类的方法，每次调用该方法都生成一个新的UUID
+ (NSString *)getUUIDString
{
    CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
    CFStringRef strRef = CFUUIDCreateString(kCFAllocatorDefault , uuidRef);
    NSString *uuidString = [(__bridge NSString*)strRef stringByReplacingOccurrencesOfString:@"-" withString:@""];
    CFRelease(strRef);
    CFRelease(uuidRef);
    return uuidString;
}

//持久化存储用户购买凭证(这里最好还要存储当前日期，用户id等信息，用于区分不同的凭证)
- (void)saveReceipt{
    NSLog(@"saveReceipt");
    
    [self checkLocalFile];
    
    NSString *fileName = [TJIAP getUUIDString];
    NSString *savedPath = [NSString stringWithFormat:@"%@%@.plist", AppStoreInfoLocalFilePath, fileName];
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         self.receipt, RECEIPT,
                         self.date, DATE,
                         self.userid, USERID,
                         nil];
    [dic writeToFile:savedPath atomically:YES];
}

- (BOOL)checkLocalFile{
     NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:AppStoreInfoLocalFilePath]) {
        [fileManager createDirectoryAtPath:AppStoreInfoLocalFilePath//创建目录
               withIntermediateDirectories:YES
                                attributes:nil
                                     error:nil];
        return NO;
    }
    return YES;
}

- (void)checkReceiptIsValidFromLocal{
    if ([self checkLocalFile]) {
        [self sendFailedIapFiles];
    }
}

//验证receipt失败,App启动后再次验证
- (void)sendFailedIapFiles{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error = nil;
    //搜索该目录下的所有文件和目录
    NSArray *cacheFileNameArray = [fileManager contentsOfDirectoryAtPath:AppStoreInfoLocalFilePath error:&error];
    if (error == nil){
        for (NSString *name in cacheFileNameArray){
            if ([name hasSuffix:@".plist"])//如果有plist后缀的文件，说明就是存储的购买凭证
            {
                NSString *filePath = [NSString stringWithFormat:@"%@/%@", AppStoreInfoLocalFilePath, name];
                [self sendAppStoreRequestBuyPlist:filePath];
            } else {
                NSLog(@"AppStoreInfoLocalFilePath error:%@", [error domain]);
            }
        }
    }
}

- (void)sendAppStoreRequestBuyPlist:(NSString *)plistPath{
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    //这里的参数请根据自己公司后台服务器接口定制，但是必须发送的是持久化保存购买凭证
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [dic objectForKey:USERID], USERID,
                                   [dic objectForKey:DATE], DATE,
                                   [dic objectForKey:RECEIPT], RECEIPT,
                                   nil];
    
}

//验证成功就从plist中移除凭证
- (void)sendAppStoreRequestSucceededWithData
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:AppStoreInfoLocalFilePath])
    {
        [fileManager removeItemAtPath:AppStoreInfoLocalFilePath error:nil];
    }
}

@end
