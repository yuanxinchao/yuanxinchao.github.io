//
//  iOSAddrInfo.h
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/3/9.
//
//

#ifndef __TubeSDK__iOSAddrInfo__
#define __TubeSDK__iOSAddrInfo__

extern "C"
{
    const char* IOSGetAddressInfo(const char *host);
}
#endif /* defined(__TubeSDK__iOSAddrInfo__) */
