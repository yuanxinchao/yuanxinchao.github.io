//
//  SDKManager.h
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/2/17.
//
//
#ifndef __TubeSDK__SDKManager__
#define __TubeSDK__SDKManager__

extern "C"
{
    void _login();
    void _pay(const char *param, int type);
}
#endif /* defined(__TubeSDK__SDKManager__) */
