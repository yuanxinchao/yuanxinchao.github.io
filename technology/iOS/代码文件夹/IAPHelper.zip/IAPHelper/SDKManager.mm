//
//  SDKManager.m
//  Unity-iPhone
//
//  Created by Jay Chen on 2017/2/17.
//
//

#import "SDKManager.h"
#import "TJIAP.h"
#import "TpMgr.h"
#include "UnityAppController.h"

extern "C" NSString *getNSStringFromCStr(const char* cstr){
    if (cstr) {
        return [NSString stringWithUTF8String:cstr];
    }
    return nil;
}

extern "C" UIViewController* getCurrentViewController(){
    
    UIViewController* ctrol = nil;
    if ( [[UIDevice currentDevice].systemVersion floatValue] < 6.0)
    {
        // warning: addSubView doesn't work on iOS6
        NSArray* array = [[UIApplication sharedApplication]windows];
        UIWindow* win = [array objectAtIndex:0];
        
        UIView* ui = [[win subviews] objectAtIndex:0];
        ctrol = (UIViewController*)[ui nextResponder];
    }
    else
    {
        // use this method on ios6
        ctrol = [UIApplication sharedApplication].keyWindow.rootViewController;
    }
    return ctrol;
}

void _login(){
    [[TpMgr sharedTpMgr] login:UnityGetGLViewController()];
}

void _pay(const char *param, int type){
    NSString *paramStr = getNSStringFromCStr(param);
    NSArray *array1 = [paramStr componentsSeparatedByString:@"&"];
    NSLog(@"array : %f", [[NSString stringWithFormat:@"%.2f", [array1[0] intValue] * 0.01f] floatValue]);
    NSLog(@"_________pay type %d", type);
    if(type == 2){
        NSArray *array = [paramStr componentsSeparatedByString:@"&"];
        [[TpMgr sharedTpMgr] pay:UnityGetGLViewController() merOrderNum:@"123" appCallbackUrl:@"http://test.tomatojoy.cn:30040" appId:@"5057" price:[[NSString stringWithFormat:@"%.2f", [array1[0] intValue] * 0.01f] floatValue] diyparam:array[2] ver:@"1.0.3" signKey:@"sv81mul7fd8934bjfFV12csjV" GoodDesc:array[1] wxappid:@"wx72ceb6ced48a650f" PayMethod:@"2" GroupId:@"74"  Chid:@"412" SlotGameId:@"4_7"];
    }else{
        [[TJIAP shareTJIAP] buyProdution:paramStr];
    }
}

